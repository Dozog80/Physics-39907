%% 1D Cahn–Hilliard Simulator
% <CH1d.m> Mark D. Shattuck 12/10/2023

% revision history:
% 12/10/2023 Mark D. Shattuck <mds> CH1d.m
%
% 12/10/2023 mds set up for PHYS 339 final
%
%% Experimental Parameters
gam = 3e-5; % control parameter
Nx  = 128; % Number of grid points on
Lx  = 1; % Size of container

TT  = .05; % Total simulation time

%% Simulation parameters
dt = 1e-6;

%% Calculated parameters
Nt = round(TT/dt); % number of Time steps
dx = Lx/Nx; % grid spacing
x  = (0:Nx-1)'*dx; % x−grid for plotting and testing

% 2nd derivative of a column vector
Dxx = toeplitz([-2 1 zeros(1,Nx-3) 1])/dx/dx;
Dxx = sparse(Dxx); % convert to sparse for speed

%% Initial condition
c = rand(Nx,1) > 1/2; % random initial condition

%% Save state
cs = zeros(Nx,Nt); % save every time step

%% Main loop
for nt = 1:Nt
    Wc = (c-1).*c.*(c-1/2);
    mu = Wc - gam*(Dxx*c);
    dc = Dxx*mu; % from equation [1]

    c = c + dt*dc; % update rule
    % give feedback by plotting
    if (rem(nt,fix(Nt/100))==0)
        plot(x,c)
        drawnow;
        disp([nt/100 mean(c(:))]);
    end

    cs(:,nt) = c; % save results
end
imagesc([0 Lx],[0 TT],cs');
xlabel('Space');
ylabel('Time');
colormap(jet(256));
