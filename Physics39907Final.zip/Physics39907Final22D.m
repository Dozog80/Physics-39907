%% 2D Cahn–Hilliard Simulator
% <CH1d.m> Mark D. Shattuck 12/10/2023

% revision history:
% 12/10/2023 Mark D. Shattuck <mds> CH1d.m
%
% 12/10/2023 mds set up for PHYS 339 final
% 12/14/2023 mds conver to 2D CH2d.m

%% Experimental Parameters
gam = 3e-5; % control parameter

Nx = 128; % Number of grid points in x
Ny = 128; % Number of grid points in y
Lx = 1; % Size of container in x
Ly = 1; % Size of container in y

TT = .05; % Total simulation time

%% Simulation parameters
dt = 1e-6;

%% Calculated parameters
Nt = round(TT/dt); % number of Time steps
dx = Lx/Nx; % x−grid spacing
dy = Ly/Ny; % y−grid spacing

% 2nd derivative of a matrix
Dxx = toeplitz([-2 1 zeros(1,Nx-3) 1])/dx/dx;
Dxx = sparse(Dxx); % convert to sparse for speed

% x = linspace(0,1-(1/Nx),Nx)' shows that Dxx works since
% Dxx*sin(2*pi*x)+(2*pi)^2*sin(2*pi*x) is approx. zero, 

Dyy = toeplitz([-2 1 zeros(1,Ny-3) 1])/dy/dy;
Dyy = sparse(Dyy); % convert to sparse for speed

%% initial conditions
c = rand(Nx,Ny) > 1/2; % random initial condition now (Nx,Ny)

%% Main loop
for nt = 1:Nt
    Wc = (c-1).*c.*(c-1/2);
    mu = Wc - gam*(Dxx*c + c*Dyy);
    dc = Dxx*mu+mu*Dyy; % from equation [1]
    c = c + dt*dc; % update rule

    % give feedback by plotting
    if rem(nt,fix(Nt/200))==0
        imagesc([0 Ly],[0 Lx],c); % now display current image
        axis image;
        colormap(jet(256));
        drawnow;
        disp([nt/Nt mean(c(:))]);
    end
end

