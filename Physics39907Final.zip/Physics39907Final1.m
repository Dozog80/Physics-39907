N=5; % Number of nodes
Ne = N-1;   % number of elements
a=3/8;
dx=1/(N-1);
Kloc = (1/30)*[4,  3, -1, -3;
             3, 36,  3, -36;
            -1,  3,  4, -3;
            -3,-36, -3, 36];
f = [0; 1/8; 1/2; -1/8; 1/2; 0; 0; 0];


% Global K
K = zeros(2*N,2*N);

for i = 0:N-2
    idx = 2*i + (1:4);
    K(idx,idx) = K(idx,idx) + Kloc; %Local K contribution
end

Ktrim = K(2:9,2:9);
x=0:dx/50:1;
u = Ktrim\f; u= (1/4)*[0;u;0;0];
U = evalFEM(x,u,dx);

%% FD (5 points Free-Fix)
function [K,T,B,C] = ktbc(N)
% ktbc <Special 2nd diff matrices.>
% Usage:: [K,T,B,C]=ktbc(N[5])
% Physics 39907 HW 4 Question 1


if (~exist('N', 'var')) || isempty(N)
    N = 5;
end

% Second-order difference operator K
K = toeplitz([2 -1 zeros(1,N-2)]);

% To create T, change first row (and all columns (1,:)) of K
T = K;
T(1,1) = 1;

% To create B, change last row (Nth row) of T so last entry of last row
% is 1
B = T;
B(N,N) = 1;

% To create C, change last entry of first row (1,N) and last entry
% of first column (N,1) of K to -1
C = K;
C(1,N) = -1;
C(N,1) = -1;

end

function u = solveFreeFix(f, x)
    % Solve -u'' = f(x) with u'(0)=0, u(1)=0 

 %% Parse Input
 % x is optional
    if ~exist('x','var') || isempty(x)
        x = 0:1/6:1; % Standard case, 6 steps from 0 to 1
    end
%% Main

    N = length(x); % size of x
    h = x(2) - x(1); % size of h nb: should check N>=1

    if length(f) ~= N-1
        error('length(f) must be length(x)-1');
    end


    [K,T,B,C] = ktbc(N); % Need B to solve system eventually
    B = B(1:N-1, 1:N-1); % Remove last row and column since u(1) = 0

    u = 1/h^2 * B \ f(:); % Solving the system, need factor of 1/h^2

    u = [u; 0]; % u(1) = 0, so last u should be 0
end

x2 = 0:dx:1;
ftrim = [f(1:4,:)];
u2 = 8*solveFreeFix(ftrim, x2);

ue=(1-x).*(x>a) + (1-a).*(x<=a); % exact solution

% plot results
h=plot(x,U,'b-', (0:N-1)*dx,u2,'ro--', x, ue,'k--');

% make it pretty
set(h,'linewidth',3,'markersize',15);
set(gca,'fontsize',20);
xlabel('$x$','interp','latex');
ylabel('$u(x)$','interp','latex');

function U=evalFEM(x,u,dx,H,S)
% evalFEM <Find value of C1 cubic FEM>
% Usage:: [U,S,H]=evalFEM(x,u,dx[1],...
% H[@(x) (2*abs(x)+1).*(abs(x)−1).ˆ2.*(abs(x)<1)],...
% S[@(x) x.*(abs(x)−1).ˆ2.*(abs(x)<1)])
%

% revision history:
% 12/10/2023 Mark D. Shattuck <mds> evalFEM.m

%% Parse Input
if(~exist('dx','var')|| isempty(dx))
    dx=1;
end
if(~exist('H','var')|| isempty(H))
    H=@(x) (2*abs(x)+1).*(abs(x)-1).^2.*(abs(x)<1);
end
if(~exist('S','var')|| isempty(S))
    S=@(x) x.*(abs(x)-1).^2.*(abs(x)<1);
end

%% Main
N=length(u)/2;
U=0;
for n=0:N-1
    U=U+u(2*n+1)*S(x/dx-n)+u(2*n+2)*H(x/dx-n);
end
end

