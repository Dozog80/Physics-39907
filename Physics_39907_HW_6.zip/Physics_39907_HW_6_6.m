function u = lccfdodes(A,u0,dt,N,itype)
% lccfdodes <Linear−Constant−Coefficient−Finite−Difference−
% Ordinary−Differential−Equation−Solver (lccfdodes)>
% Usage:: u=lccfdodes(A,u0,dt,N,itype{['FE'],'BE','TP','LF'})
%
% Solves du/dt=Au with u(0)=u0 t=(0:N−1)*dt; u(:,n) and u0 are 
% column vectors
% 
% revision history:
% 11/01/2023 Mark D. Shattuck <mds> lccfdodes.m
% Supported integration types:

%% Parse Input
if (~exist('itype','var') || isempty(itype))
    itype = 'FE';
end
itype = upper(itype); % So that the case of itype doesn't matter

%% Main 
M = length(u0); % number of equations
u = zeros(M,N); % initialize u(t) to zeros, one Mx1 vector for each of 
% N times
u(:,1) = u0; % set initial condition
I = eye(M); % Identity, the same size as number of eq's

%% define growth factor G
switch itype
    case 'FE'  
        G = I + dt*A; % Forward Euler
    case 'BE'  
        G = (I - dt*A)\I; % backward Euler
    case 'TP'  
        G = (I - (dt/2)*A)\(I + (dt/2)*A); % trapazoid method 2nd−order
    case 'ME'  
        L = tril(A,-1); % Lower-triangular part
        U = A - L; % Upper-triangular part
        G = (I - L*dt)\(I + U*dt); % explicit modified Euler
end

% loop over times 1 through N−1
for n = 1:N-1
    u(:,n+1) = G * u(:,n); % update u n+1 using G and u n
end
end

%% Linear Predator-Prey Model
A = [6 -2; 2 1]; % Coefficient matrix
[S,e] = eig(sym(A)); % To check answer for eigvals and eigvecs
u0 = [10; 10];  % Initial population
dt = 1/20; % Time step
T = 5; % Total time
t = 0:dt:T; % Times
N = numel(t); % Time points

u = zeros(2, N); % Pre-allocate 
for n = 1:N
    u(:,n) = expm(A*t(n))*u0;
end

r = u(1,:);
f = u(2,:);

% Solving for every type of integration scheme
u_FE = lccfdodes(A,u0,dt,N,'FE');
u_BE = lccfdodes(A,u0,dt,N,'BE');
u_TP = lccfdodes(A,u0,dt,N,'TP');
u_ME = lccfdodes(A,u0,dt,N,'ME');

% plotting the ratio of rabbits to foxes over time for different 
% integration schemes
clf;
plot(t, r./f, 'ko', 'DisplayName','Exact');
xlabel('Time (t)');
ylabel('Ratio of Rabbits to Foxes (r/f)');
hold on;
plot(t, u_FE(1,:)./u_FE(2,:), 'r.-', 'DisplayName','Forward Euler');
plot(t, u_BE(1,:)./u_BE(2,:), 'g.-', 'DisplayName','Backward Euler');
plot(t, u_TP(1,:)./u_TP(2,:), 'c-', 'DisplayName','TP');
plot(t, u_ME(1,:)./u_ME(2,:), 'y.-', 'DisplayName','ME');
legend('Location','best');
title('Comparison of Integration Schemes in Linear Predator-Prey Model');

% % Code to compare exact solution to MATLAB's ode45
% sol=deval(ode45(@(t,u) A*u, [0 T], u0), t);
% clf;
% plot(t, sol(1,:)./sol(2,:), 'ko');
% hold on;
% plot(t, r./f, 'r-');
% legend('ode45','Exact');
% xlabel('Time (t)');
% ylabel('Ratio of Rabbits to Foxes (r/f)');
% title('Comparison of Exact Solution to ode45');
% 
