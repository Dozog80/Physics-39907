function [K,T,B,C] = ktbc(N)
% ktbc <Special 2nd diff matrices.>
% Usage:: [K,T,B,C]=ktbc(N[5])
% Physics 39907 HW 4 Question 1
if (~exist('N', 'var')) || isempty(N)
    N = 5;
end

% Second-order difference operator K
K = toeplitz([2 -1 zeros(1,N-2)]);

% To create T, change first row (and all columns (1,:)) of K
T = K;
T(1,1) = 1;

% To create B, change last row (Nth row) of T so last entry of last row
% is 1
B = T;
B(N,N) = 1;

% To create C, change last entry of first row (1,N) and last entry
% of first column (N,1) of K to -1
C = K;
C(1,N) = -1;
C(N,1) = -1;

end

% % [K,T,B,C]=ktbc(5) being the standard case
N=5;
[K,T,B,C]=ktbc(5);
e = eig(K); % Eigenvalues of K_5

% Theoretical Eigenvalues
h = 1/(N+1);
k = (1:N)';
lam = 2*(1 - cos(k*pi*h));

% Comparison, showing eigenvalues match
[e lam]
disp('Difference:') % Approximately 0
disp(e - lam)