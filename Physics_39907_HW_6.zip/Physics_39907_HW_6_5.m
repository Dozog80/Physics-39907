function u = lccfdodes(A,u0,dt,N,itype)
% lccfdodes <Linear−Constant−Coefficient−Finite−Difference−
% Ordinary−Differential−Equation−Solver (lccfdodes)>
% Usage:: u=lccfdodes(A,u0,dt,N,itype{['FE'],'BE','TP','LF'})
%
% Solves du/dt=Au with u(0)=u0 t=(0:N−1)*dt; u(:,n) and u0 are 
% column vectors
% 
% revision history:
% 11/01/2023 Mark D. Shattuck <mds> lccfdodes.m
% Supported integration types:

%% Parse Input
if (~exist('itype','var') || isempty(itype))
    itype = 'FE';
end
itype = upper(itype); % So that the case of itype doesn't matter

%% Main 
M = length(u0); % number of equations
u = zeros(M,N); % initialize u(t) to zeros, one Mx1 vector for each of 
% N times
u(:,1) = u0; % set initial condition
I = eye(M); % Identity, the same size as number of eq's

%% define growth factor G
switch itype
    case 'FE'  
        G = I + dt*A; % Forward Euler
    case 'BE'  
        G = (I - dt*A)\I; % backward Euler
    case 'TP'  
        G = (I - (dt/2)*A)\(I + (dt/2)*A); % trapazoid method 2nd−order
    case 'ME'  
        L = tril(A,-1); % Lower-triangular part
        U = A - L; % Upper-triangular part
        G = (I - L*dt)\(I + U*dt); % explicit modified Euler
end

% loop over times 1 through N−1
for n = 1:N-1
    u(:,n+1) = G * u(:,n); % update u n+1 using G and u n
end
end

%% Parmeters, Initial Conditions
T1 = 10; % Initial Relaxation Times
T2 = 10;
B  = [0; 0; 1]; % Initial B field
m0 = [1; 0; 0]; % Initial magnetic moment
dt = 0.1; % Time step
T  = 100; % Total time
N  = T/dt; % Time points

%% A and b from dm/dt = Am + b
A = [-1/T2, 1, 0;  -1, -1/T2, 0;  0, 0, -1/T1]; 
b = [0; 0; 1/T1];

%% Initial condition for u
u0 = m0 + A\b;  

%% Solve du/dt = A*u  
u = lccfdodes(A,u0,dt,N,'TP'); % using trapezoidal integration scheme, 
% can change to other integration schemes like FE, BE, or ME

%% Recovering real solution m from u
m = u - A\b;

%% 3D Plot 
clf;
plot3(m(1,:), m(2,:), m(3,:));
xlabel('m_x'); 
ylabel('m_y'); 
zlabel('m_z');
axis equal;
title('Magnetic Dipole in a Magnetic Field');
set(gca,'fontsize',15); % make font larger
