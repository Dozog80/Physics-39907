function [K,T,B,C] = ktbc(N)
% ktbc <Special 2nd diff matrices.>
% Usage:: [K,T,B,C]=ktbc(N[5])
% Physics 39907 HW 4 Question 1


if (~exist('N', 'var')) || isempty(N)
    N = 5;
end

% Second-order difference operator K
K = toeplitz([2 -1 zeros(1,N-2)]);

% To create T, change first row (and all columns (1,:)) of K
T = K;
T(1,1) = 1;

% To create B, change last row (Nth row) of T so last entry of last row
% is 1
B = T;
B(N,N) = 1;

% To create C, change last entry of first row (1,N) and last entry
% of first column (N,1) of K to -1
C = K;
C(1,N) = -1;
C(N,1) = -1;

end

% % [K,T,B,C]=ktbc(5) being the standard case


function u = solveFreeFree(f, x)
% solveFixFix <Solve −u'(x)=f(x) with u'(a)=0, u'(b)=0 on the 
% interval x=[a:h:b]>, also with u(1) = 0 to get a unique solution

N = length(x); % size of x
[K,T,B,C] = ktbc(N); % Using B matrix to solve system eventually
h = 1/(N-1); % Size of step
B = B / h^2; % To include factor of 1/h^2

B(end,:) = 0; 
B(end,end) = 1; % u(1) = 0, isolating only the last u
f(end) = 0; % u(1) = 0, setting the last u equal to 0 for unique solution

u = B \ f; % Solving the system
end

%% Plot multiple
clf; % clear figure

hlist = [1/6, 1/11, 1/50]; % list of h values
mk = {'s','+','o'}; % list of markers
xx=0:.01:1;  % x−values for exact solution

%% (a) Has no solution

%% (b) f(x) = delta(x-1/3) - delta(x-2/3)
figure(1); clf;

%Exact solution, from Green's functions, which are the solutions of the 
%delta functions, which creates a piecewise function
u_exact = @(x) -( ...
    ((x < 1/3) .* ((x - 1) * (1/3 - 0.5)) + (x >= 1/3) .* ((1/3 - 1) * (x - 0.5))) ...
  - ((x < 2/3) .* ((x - 1) * (2/3 - 0.5)) + (x >= 2/3) .* ((2/3 - 1) * (x - 0.5))) );


plot(xx, -u_exact(xx), 'k--', 'linewidth', 3); hold on;

% For loop for finite differences solutions for different h values 
for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = zeros(N,1); % Initialize f

    % Discrete delta function approximations, maybe source of error
    [~, idx1] = min(abs(x - 1/3)); % Index of point closest to 1/3
    [~, idx2] = min(abs(x - 2/3)); % Index of point closest to 2/3
    f(idx1) = 1/h; % Delta functions, with 1/h as mentioned in previous 
    % script to obey delta function condition that sum over interval is 1
    f(idx2) = -1/h;

    % Finite differences solution, subtract end of exact solution to match
    % at end
    u_fd = solveFreeFree(f, x); 
    plot(x, u_fd - u_exact(end), mk{nh}, 'markersize', 8, 'linewidth', 1.5);

end

title('(b) f(x) = \delta(x - 1/3) - \delta(x - 2/3)');
legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
xlabel('x');
ylabel('u(x)');


%% (c) f(x) = sin(2pi x)
figure(2); clf;
% Exact solution, valid up to a constant, obtained by integrating twice and
% using boundary conditions
u_exact = @(x) sin(2*pi*x)/(4*pi^2) - x/(2*pi); 
plot(xx, u_exact(xx), 'k--', 'linewidth', 3); hold on;

for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    f = sin(2*pi*x)'; % f for (c)
    u = solveFreeFree(f, x);% Finite differences solution, subtract 
    % constant at end to match exact solution
    plot(x, u - u(1), mk{nh}, 'linewidth', 1.5); 
end
title('(c) f(x) = sin(2\pi x)');
legend('Exact Solution','h=1/6','h=1/11','h=1/50');
xlabel('x'); ylabel('u(x)');


