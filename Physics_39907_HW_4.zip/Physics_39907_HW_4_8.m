N = 6; % Example size
% Example of u and v
u = (1:N)'; % 1, 2, 3, ..., N as a column
v = (N:-1:1)'; % N, N-1, ... 3, 2, 1 as a column

LHS = 0; % Left hand side of discrete equation
for i = 1:N-1
    LHS = LHS + u(i)*(v(i+1) - v(i));
end

RHS = 0; % Right hand side of discrete equation
for i = 1:N-1
    RHS = RHS - (-u(i) + u(i+1))*v(i+1);
end

fprintf('LHS = %f\n', LHS);
fprintf('RHS = %f\n', RHS); % Verifying the relationship, they are equal




