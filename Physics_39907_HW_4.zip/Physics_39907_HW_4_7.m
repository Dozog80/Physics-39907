N = 4;  % Number of points

%% First forward difference Operator D_fd
diags = ones(N,1);
D = spdiags([-diags diags], [0 1], N-1, N); % spdiags takes columns of first entry 
% and places them along the diagonals specified by the second entry, and 
% makes a matrix with dimensions specified by the last two entries, here 
% the dimensions are (N-1) x N

disp('Forward Difference Operator D_fd:');
disp(full(D));

%% Summation matrix S and S inverse = D_inv
S = tril(ones(N)); % Lower triangulart matrix of ones
I = eye(size(S)); % Identity matrix that is the same size as S
D_inv = S \ I; % Inverse of summation matrix using identity matrix above

disp('Summation Matrix S:');
disp(S);

disp('S inverse = D_inv:');
disp(D_inv);

%% Matrices K, B, T, and (D_inv^T)D_inv
K = D * D'; % D(D^T)
B = D' * D;  % (D^T)D
T = D_inv * D_inv'; % D_inv(D_inv^T)
X = D_inv' * D_inv; % (D_inv^T)D_inv

disp('K = D(D^T):');
disp(full(K));

disp('B = (D^T)D:');
disp(full(B));

disp('T = D_inv(D_inv^T):');
disp(T);

disp('X = (D_inv^T)D_inv:');
disp(X);