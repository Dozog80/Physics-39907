function [K,T,B,C] = ktbc(N)
% ktbc <Special 2nd diff matrices.>
% Usage:: [K,T,B,C]=ktbc(N[5])
% Physics 39907 HW 4 Question 1


if (~exist('N', 'var')) || isempty(N)
    N = 5;
end

% Second-order difference operator K
K = toeplitz([2 -1 zeros(1,N-2)]);

% To create T, change first row (and all columns (1,:)) of K
T = K;
T(1,1) = 1;

% To create B, change last row (Nth row) of T so last entry of last row
% is 1
B = T;
B(N,N) = 1;

% To create C, change last entry of first row (1,N) and last entry
% of first column (N,1) of K to -1
C = K;
C(1,N) = -1;
C(N,1) = -1;

end

% % [K,T,B,C]=ktbc(5) being the standard case


function u=solveFixFix(f,x)
% solveFixFix <Solve −u'(x)=f(x) with u(a)=0, u(b)=0 on the interval x=[a:h:b]>
% Usage:: u=solveFixFix(f,x[0:1/6:1])
%
%% Parse Input
% x is optional
if (~exist('x','var') || isempty(x))
    x = 0:1/6:1; % Standard conditions, 6 steps from 0 to 1
end

%% Main

N = length(x); % size of x
h = x(2) - x(1); % size of h nb: should check N>=2

if length(f) ~= N-2
    disp('length(f) must be length(x)-2');
    u=-1;
    return
end

K = (1/h^2) * ktbc(N-2); % Need factor of 1/h^2, b.c. mean we know two pts 
% so only need N-2 matrix


    u = K \ f(:); % Solving the system
    u = [0; u; 0]; % u(0) = u(1) = 0, so first and last u should be 0
end

% Plot multiple
clf;% clear figure

xx = 0:.01:1; % x−values for exact solution
hlist = [1/6 1/11 1/50]; % list of h values
mk = {'s','+','o'}; % list of markers

%% (1) f(x) = 1
figure(1); clf;
%Exact solution, from integrating twice and applying boundary conditions
plot(xx, (1-xx).*xx/2, 'k--', 'LineWidth', 3); 
hold on;
for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = ones(N-2, 1); % f(x) = 1, b.c. mean we know two pts already
    u = solveFixFix(f, x); % Finite differences solution

    plot(x, u, mk{nh}, 'markersize', 7, 'linewidth', 2);
end
legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
xlabel('x'); ylabel('u(x)');
title('(1) f(x) = 1');
hold off;

%% (2) f(x) = δ(x - 2/3)
figure(2); clf;
%Exact solution, from integrating twice and applying boundary conditions
u_exact = zeros(size(xx));
u_exact(xx < 2/3) = xx(xx < 2/3)/3;
u_exact(xx >= 2/3) = (2/3) * (1 - xx(xx >= 2/3));
plot(xx, u_exact, 'k--', 'LineWidth', 3);  
hold on;
for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = zeros(N-2,1); % b.c. mean we know two pts already
    [~, idx] = min(abs(x(2:end-1) - 2/3)); % Index closest to 2/3
    f(idx) = 1/h;  % approximate delta function, so sum over interval is 1
    u = solveFixFix(f, x); % Finite differences solution 
    plot(x, u, mk{nh}, 'markersize', 10, 'linewidth', 2);
end
legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
xlabel('x'); ylabel('u(x)');
title('(2) f(x) = δ(x - 2/3)');
hold off;

%% (3) f(x) = sin(pi * x)
figure(3); clf;
%Exact solution, from integrating twice and applying boundary conditions
plot(xx, (1/pi^2) * sin(pi * xx), 'k--', 'LineWidth', 3); % Analytic
hold on;
for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = sin(pi * x(2:end-1))'; % b.c. mean we know two pts already
    u = solveFixFix(f, x); % Finite differences solution 
    plot(x, u, mk{nh}, 'markersize', 10, 'linewidth', 2);
end
legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
xlabel('x'); ylabel('u(x)');
title('(3) f(x) = sin(\pi x)');
hold off;
