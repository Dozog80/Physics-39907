function [K,T,B,C] = ktbc(N)
% ktbc <Special 2nd diff matrices.>
% Usage:: [K,T,B,C]=ktbc(N[5])
% Physics 39907 HW 4 Question 1


if (~exist('N', 'var')) || isempty(N)
    N = 5;
end

% Second-order difference operator K
K = toeplitz([2 -1 zeros(1,N-2)]);

% To create T, change first row (and all columns (1,:)) of K
T = K;
T(1,1) = 1;

% To create B, change last row (Nth row) of T so last entry of last row
% is 1
B = T;
B(N,N) = 1;

% To create C, change last entry of first row (1,N) and last entry
% of first column (N,1) of K to -1
C = K;
C(1,N) = -1;
C(N,1) = -1;

end

% % [K,T,B,C]=ktbc(5) being the standard case


function u = solveFreeFix(f, x)
    % Solve -u'' = f(x) with u'(0)=0, u(1)=0 

 %% Parse Input
 % x is optional
    if ~exist('x','var') || isempty(x)
        x = 0:1/6:1; % Standard case, 6 steps from 0 to 1
    end
%% Main

    N = length(x); % size of x
    h = x(2) - x(1); % size of h nb: should check N>=1

    if length(f) ~= N-1
        error('length(f) must be length(x)-1');
    end


    [K,T,B,C] = ktbc(N); % Need B to solve system eventually
    B = B(1:N-1, 1:N-1); % Remove last row and column since u(1) = 0

    u = 1/h^2 * B \ f(:); % Solving the system, need factor of 1/h^2

    u = [u; 0]; % u(1) = 0, so last u should be 0
end


%% Plot multiple

clf; % clear figure
xx = 0:0.01:1; % x−values for exact solution
hlist = [1/6, 1/11, 1/50]; % list of h values
mk = {'s','+','o'};  % list of markers

%% (1) f(x) = 1
figure(1); clf;
%Exact solution, from integrating twice and applying boundary conditions
plot(xx, 0.5 * (1 - xx.^2), 'k--', 'LineWidth', 3); hold on;

% For loop for finite differences solutions for different h values 
for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = ones(N-1, 1); % remove last value since we know u(1) = 0
    u = solveFreeFix(f, x); % Finite differences solution
    plot(x, u, mk{nh}, 'markersize', 7, 'linewidth', 1);
end

legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
title('(1) f(x) = 1');
xlabel('x'); ylabel('u(x)'); grid on;

%% (2) f(x) = 1 - x
figure(2); clf;
%Exact solution, from integrating twice and applying boundary conditions
plot(xx, (1/6)*xx.^3 - 0.5*xx.^2 + 1/3, 'k--', 'LineWidth', 3); hold on;

for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = 1 - x(1:end-1); % remove last value since we know u(1) = 0
    u = solveFreeFix(f, x); % Finite differences solution
    plot(x, u, mk{nh}, 'markersize', 7, 'linewidth', 2);
end

legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
title('(2) f(x) = 1 - x');
xlabel('x'); ylabel('u(x)'); grid on;

%% (3) f(x) = δ(x - 1/3)
figure(3); clf;

%Exact solution, from integrating twice and applying boundary conditions
u_exact = zeros(size(xx));
u_exact(xx < 1/3) = 2/3;
u_exact(xx >= 1/3) = -xx(xx>=1/3) + 1;
plot(xx, u_exact, 'k--', 'LineWidth', 3);
hold on;

for nh = 1:length(hlist)
    h = hlist(nh); % set h
    x = 0:h:1; % make new x
    N = length(x); % length of x
    f = zeros(N-1, 1); % remove last value since we know u(1) = 0
    [~, idx] = min(abs(x(1:end-1) - 1/3)); %Index of grid point closest to
    % 1/3, where the delta function is
    f(idx) = 1/h;  % Need sum over all points to equal 1 to satisfy delta
    % function conditions, so f(idx) * h = 1, all other points are 0. 
    u = solveFreeFix(f, x); % Finite differences solution
    plot(x, u, mk{nh}, 'markersize', 4, 'linewidth', 2);
end

legend('Exact Solution', 'h=1/6', 'h=1/11', 'h=1/50');
title('(3) f(x) = \delta(x - 1/3)');
xlabel('x'); ylabel('u(x)'); grid on;

